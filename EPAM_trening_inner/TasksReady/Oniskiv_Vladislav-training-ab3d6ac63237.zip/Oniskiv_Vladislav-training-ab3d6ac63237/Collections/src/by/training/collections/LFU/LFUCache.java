package by.training.collections.LFU;

import java.util.*;

/**
 * The type Lfu cache.
 *
 * @param <K> the type parameter
 * @param <V> the type parameter
 */
public class LFUCache<K, V> extends LinkedHashMap<K, V> {
    private int capacity;
    private static final float LOADFACTOR = 0.75f;
    private Map<K, Integer> countQueue;

    /**
     * Instantiates a new Lfu cache.
     *
     * @param capacity the capacity
     */
    public LFUCache(final int capacity) {
        super(capacity, LOADFACTOR, true);
        this.capacity = capacity;
        countQueue = new LinkedHashMap<K, Integer>();
    }

    @Override
    protected boolean removeEldestEntry(final Map.Entry<K, V> eldest) {
        return size() > this.capacity;
    }

    @Override
    public V get(final Object key) {
        V value = null;
        if (containsKey(key)) {
            System.out.println("   Get from cache, key: " + key);
            countQueue.put((K) key, countQueue.get(key) + 1);
            value = super.get(key);
        }
        return value;
    }

    @Override
    public V put(final K key, final V value) {
        if (size() == capacity) {
            K keyForRemove = searchKey();
            countQueue.remove(keyForRemove);
            remove(keyForRemove);
            System.out.println("      Removed from the cache, key: " + keyForRemove);
        }
        countQueue.put(key, 1);
        System.out.println("         Added cache, key: " + key + ", value: " + value);
        return super.put(key, value);
    }

    private K searchKey() {
        K key = countQueue.keySet().iterator().next();
        int minCount = countQueue.get(key);
        for (Map.Entry<K, Integer> k : countQueue.entrySet()) {
            if (k.getValue() < minCount) {
                minCount = k.getValue();
                key = k.getKey();
            }
        }
        return key;
    }
}
