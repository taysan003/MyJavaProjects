package by.training.collections;

import by.training.collections.LRU.LRUCache;
import by.training.collections.LFU.LFUCache;

import java.util.Collections;
import java.util.Map;

/**
 * The type Main.
 */
public final class Main {

    private Main() {
    }

    /**
     * Main.
     *
     * @param args the args
     */
    public static void main(final String[] args) {
        int capacity = 3;
        Integer[] keys = new Integer[]{10, 20, 30, 40, 50};
        Map<Integer, String> cacheLRU = Collections.synchronizedMap(new LRUCache<Integer, String>(capacity));
        System.out.println("       LRU Cache");
        cacheLRU.put(keys[0], String.valueOf(keys[0] * 2));
        cacheLRU.put(keys[1], String.valueOf(keys[1] * 2));
        cacheLRU.put(keys[2], String.valueOf(keys[2] * 2));
        System.out.println("Value: " + cacheLRU.get(keys[2]));
        System.out.println("Value: " + cacheLRU.get(keys[0]));
        System.out.println("Value: " + cacheLRU.get(keys[0]));
        System.out.println("Value: " + cacheLRU.get(keys[2]));
        System.out.println("Value: " + cacheLRU.get(keys[1]));
        System.out.println("Cache: " + cacheLRU);
        cacheLRU.put(keys[3], String.valueOf(keys[3] * 2));
        System.out.println("Cache: " + cacheLRU);
        System.out.println("Value: " + cacheLRU.get(keys[3]));
        System.out.println("Value: " + cacheLRU.get(keys[3]));
        cacheLRU.put(keys[4], String.valueOf(keys[4] * 2));
        System.out.println("Cache: " + cacheLRU);
        Map<Integer, String> cacheLFU = Collections.synchronizedMap(new LFUCache<Integer, String>(capacity));
        System.out.println("\n\n\n       LFU Cache");
        cacheLFU.put(keys[0], String.valueOf(keys[0] * 2));
        cacheLFU.put(keys[1], String.valueOf(keys[1] * 2));
        cacheLFU.put(keys[2], String.valueOf(keys[2] * 2));
        System.out.println("Value: " + cacheLFU.get(keys[2]));
        System.out.println("Value: " + cacheLFU.get(keys[0]));
        System.out.println("Value: " + cacheLFU.get(keys[0]));
        System.out.println("Value: " + cacheLFU.get(keys[2]));
        System.out.println("Value: " + cacheLFU.get(keys[1]));
        System.out.println("Cache: " + cacheLFU);
        cacheLFU.put(keys[3], String.valueOf(keys[3] * 2));
        System.out.println("Cache: " + cacheLFU);
        System.out.println("Value: " + cacheLFU.get(keys[3]));
        System.out.println("Value: " + cacheLFU.get(keys[3]));
        cacheLFU.put(keys[4], String.valueOf(keys[4] * 2));
        System.out.println("Cache: " + cacheLFU);
    }
}
