package by.training.collections.LRU;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * The type Lru cache.
 *
 * @param <K> the type parameter
 * @param <V> the type parameter
 */
public class LRUCache<K, V> extends LinkedHashMap<K, V> {
    private int capacity;
    private static final float LOADFACTOR = 0.75f;

    /**
     * Instantiates a new Lru cache.
     *
     * @param capacity the capacity
     */
    public LRUCache(final int capacity) {
        super(capacity, LOADFACTOR, true);
        this.capacity = capacity;
    }

    @Override
    protected boolean removeEldestEntry(final Map.Entry<K, V> eldest) {
        return size() > this.capacity;
    }

    @Override
    public V get(final Object key) {
        V value = null;
        if (containsKey(key)) {
            System.out.println("   Get from cache, key: " + key);
            value = super.get(key);
        }
        return value;
    }

    @Override
    public V put(final K key, final V value) {
        System.out.println("         Added cache, key: " + key + ", value: " + value);
        return super.put(key, value);
    }
}
