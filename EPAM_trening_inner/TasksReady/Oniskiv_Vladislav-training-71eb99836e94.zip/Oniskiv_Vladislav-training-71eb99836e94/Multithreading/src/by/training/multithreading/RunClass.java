package by.training.multithreading;

import java.util.Map;
import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;

/**
 * Created by Vladislav on 22.06.2016.
 */
public class RunClass implements Runnable {
    private Map cache;
    private CyclicBarrier barrier;

    /**
     * Instantiates a new Run class.
     *
     * @param cache   the cache
     * @param barrier the barrier
     */
    public RunClass(final Map cache, final CyclicBarrier barrier) {
        this.cache = cache;
        this.barrier = barrier;
    }

    @Override
    public void run() {
        Integer[] keys = new Integer[]{10, 20, 30, 40, 50};
        try {
            barrier.await();
        } catch (InterruptedException | BrokenBarrierException e) {
            e.printStackTrace();
        }
        cache.put(keys[0], String.valueOf(keys[0] * 2));
        cache.put(keys[1], String.valueOf(keys[1] * 2));
        cache.put(keys[2], String.valueOf(keys[2] * 2));
        System.out.println("Value: " + cache.get(keys[0]));
        System.out.println("Value: " + cache.get(keys[2]));
        System.out.println("Cache: " + cache);
        cache.put(keys[3], String.valueOf(keys[3] * 2));
        System.out.println("Cache: " + cache);
        System.out.println("Value: " + cache.get(keys[3]));
        System.out.println("Value: " + cache.get(keys[3]));
        cache.put(keys[4], String.valueOf(keys[4] * 2));
        System.out.println("Cache: " + cache);
    }
}
