package by.training.multithreading.LRU;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * The type Lru cache.
 *
 * @param <K> the type parameter
 * @param <V> the type parameter
 */
public class LRUCache<K, V> extends LinkedHashMap<K, V> {
    private int capacity;
    private static final float LOADFACTOR = 0.75f;
    private ReadWriteLock lock;
    private Lock readerLock;
    private Lock writerLock;

    /**
     * Instantiates a new Lru cache.
     *
     * @param capacity the capacity
     */
    public LRUCache(final int capacity) {
        super(capacity, LOADFACTOR, true);
        this.capacity = capacity;
        lock = new ReentrantReadWriteLock();
        readerLock = lock.readLock();
        writerLock = lock.writeLock();
    }

    @Override
    protected boolean removeEldestEntry(final Map.Entry<K, V> eldest) {
        return size() > this.capacity;
    }

    @Override
    public V get(final Object key) {
        V value = null;
        readerLock.lock();
        try {
            if (containsKey(key)) {
                System.out.println("   Get from cache, key: " + key);
                value = super.get(key);
            }
        } finally {
            readerLock.unlock();
        }
        return value;
    }

    @Override
    public V put(final K key, final V value) {
        writerLock.lock();
        try {
            System.out.println("         Added cache, key: " + key + ", value: " + value);
            return super.put(key, value);
        } finally {
            writerLock.unlock();
        }
    }
}
