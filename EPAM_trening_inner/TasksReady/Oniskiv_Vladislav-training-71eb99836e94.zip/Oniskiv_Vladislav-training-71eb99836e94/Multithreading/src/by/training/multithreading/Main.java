package by.training.multithreading;

import by.training.multithreading.LFU.LFUCache;
import by.training.multithreading.LRU.LRUCache;

import java.util.Map;
import java.util.concurrent.*;

/**
 * The type Main.
 */
public final class Main {
    private Main() {
    }

    /**
     * Main.
     *
     * @param args the args
     */
    public static void main(final String[] args) {
        int countThreads = 3;
        int capacity = 3;
        System.out.println("       LRU Cache");
        CyclicBarrier barrier = new CyclicBarrier(countThreads);
        Map<Integer, String> cache = new LRUCache<Integer, String>(capacity);
        ExecutorService service = Executors.newFixedThreadPool(countThreads);
        for (int i = 0; i < countThreads; i++) {
            service.submit(new RunClass(cache, barrier));
        }
        try {
            service.awaitTermination(1, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        service.shutdown();
        System.out.println("\n\n\n       LFU Cache");
        barrier = new CyclicBarrier(countThreads);
        cache = new LFUCache<Integer, String>(capacity);
        service = Executors.newFixedThreadPool(countThreads);
        for (int i = 0; i < countThreads; i++) {
            service.submit(new RunClass(cache, barrier));
        }
        service.shutdown();
    }
}
