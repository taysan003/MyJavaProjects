import by.gsu.epamlab.beans.SomeClass;

public class HelloWorld {
	public static void main(String[] args) {
		SomeClass sc = new SomeClass();
		System.out.println(sc);
	}
}
