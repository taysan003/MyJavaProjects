package by.training.javalab.utils;

import by.training.javalab.annotation.Equal;

import java.lang.reflect.Field;

/**
 * Created by Artsemi Novikau on 30.06.2016.
 */
public final class PaperAnalyzer {
    private PaperAnalyzer() { }

    /**
     * Check two objects for equality. If their fields, that marked
     * with annotation @Equal, have a same value (or a same reference),
     * then objects are equal. If fields have different annotations,
     * then objects are not equal
     * @param o1 first object
     * @param o2 second object
     * @return true, if both objects are equal, false if they aren't
     * @throws IllegalAccessException class member access denied
     */
    public static boolean equalObjects(final Object o1, final Object o2) throws IllegalAccessException {
        boolean isEqual = false;

        Field[] firstObjectFields = o1.getClass().getDeclaredFields();
        Field[] secondObjectFields = o2.getClass().getDeclaredFields();
        for (Field field1 : firstObjectFields) {
            if (!field1.isAccessible()) {
                field1.setAccessible(true);
            }
            if (field1.isAnnotationPresent(Equal.class)) {
                for (Field field2 : secondObjectFields) {
                    if (!field2.isAccessible()) {
                        field2.setAccessible(true);
                    }
                    if (field1.getName().equals(field2.getName())) {
                        Equal.CompareBy compareBy = field1.getAnnotation(Equal.class).compareBy();
                        if (!(compareBy.equals(field2.getAnnotation(Equal.class).compareBy()))) {
                            isEqual = false;
                        }

                        if (compareBy.equals(Equal.CompareBy.REFERENCE)) {
                            isEqual = (field1.get(o1) == field2.get(o2));
                        } else if (compareBy.equals(Equal.CompareBy.VALUE)) {
                            isEqual = field1.get(o1).equals(field2.get(o2));
                        }
                    }
                }
            }
        }
        return isEqual;
    }
}
