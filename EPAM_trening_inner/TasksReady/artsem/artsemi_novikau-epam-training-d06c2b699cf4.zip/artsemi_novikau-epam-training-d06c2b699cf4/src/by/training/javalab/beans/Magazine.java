package by.training.javalab.beans;

import by.training.javalab.annotation.Equal;
import by.training.javalab.annotation.Proxy;
import by.training.javalab.handler.ProxyHandler;
import by.training.javalab.iface.IPaper;

/**
 * Created by Artsemi Novikau on 30.06.2016.
 */

@Proxy(handler = ProxyHandler.class)
public class Magazine implements IPaper {
    @Equal(compareBy = Equal.CompareBy.REFERENCE)
    private String name;
    private double price;
    @Equal(compareBy = Equal.CompareBy.VALUE)
    private int pageCount;

    /**
     * General-purpose constructor that invokes has some default values
     */
    public Magazine() {
        this.pageCount = 50;
        this.name = "People";
        this.price = 25.00;
    }

    /**
     * Constructor with params
     * @param pageCount count of pages
     * @param name name of magazine
     * @param price price
     */
    public Magazine(final int pageCount, final String name, final double price) {
        this.pageCount = pageCount;
        this.name = name;
        this.price = price;
    }

    @Override
    public void print() {
        System.out.printf("%s has %d pages and costs %.2f$",
                name, pageCount, price);
    }
}
