package by.training.javalab.beans;

import by.training.javalab.annotation.Equal;
import by.training.javalab.iface.IPaper;

/**
 * Created by Artsemi Novikau on 30.06.2016.
 */
public class Newspaper implements IPaper {
    @Equal(compareBy = Equal.CompareBy.REFERENCE)
    private String name;
    private double price;
    @Equal(compareBy = Equal.CompareBy.VALUE)
    private int pageCount;

    /**
     * General-purpose constructor that invokes super()
     */
    public Newspaper() {
        super();
    }

    /**
     * Constructor with params
     * @param pageCount count of pages
     * @param name name of newspaper
     * @param price price
     */
    public Newspaper(final int pageCount, final String name, final double price) {
        this.name = name;
        this.price = price;
        this.pageCount = pageCount;
    }

    @Override
    public void print() {
        System.out.printf("%s has %d pages and costs %.2f$",
                name, pageCount, price);
    }
}
