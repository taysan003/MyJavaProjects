package by.training.javalab.runners;

import by.training.javalab.beans.Magazine;
import by.training.javalab.beans.Newspaper;
import by.training.javalab.factory.ProxyFactory;
import by.training.javalab.iface.IPaper;
import by.training.javalab.utils.PaperAnalyzer;

import java.lang.reflect.InvocationTargetException;

/**
 * Created by Artsemi Novikau on 04.07.2016.
 */
public final class Runner {
    private Runner() { }

    /**
     * Main method.
     * @param args command line arguments
     */
    public static void main(final String[] args) {
        IPaper paper1 = new Magazine(50, "Time", 25.00);
        IPaper paper2 = new Magazine(50, "Time", 30.00);
        IPaper paper3 = new Newspaper(65, "Time", 25.00);
        try {
            System.out.println(PaperAnalyzer.equalObjects(paper1, paper2));
            System.out.println(PaperAnalyzer.equalObjects(paper1, paper3));
            IPaper instance = (IPaper) ProxyFactory.getInstance(Magazine.class);
            instance.print();
        } catch (NoSuchMethodException | InstantiationException
                | IllegalAccessException | InvocationTargetException e) {
            e.printStackTrace();
        }
    }
}
