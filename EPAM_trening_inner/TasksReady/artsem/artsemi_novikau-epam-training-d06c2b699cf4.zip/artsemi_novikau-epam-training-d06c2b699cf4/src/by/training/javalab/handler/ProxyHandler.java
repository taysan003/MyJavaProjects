package by.training.javalab.handler;

import by.training.javalab.iface.IPaper;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

/**
 * Created by Artsemi Novikau on 30.06.2016.
 */
public class ProxyHandler implements InvocationHandler {
    private IPaper paper;

    /**
     * Handler constructor
     * @param paper an object which method is invoked
     */
    public ProxyHandler(final IPaper paper) {
        this.paper = paper;
    }

    @Override
    public Object invoke(final Object proxy, final Method method, final Object[] args) throws Throwable {
        System.out.println("Proxy invoked. Method : " + method.getName());
        return method.invoke(paper, args);
    }
}
