package by.training.javalab.iface;

/**
 * Created by Artsemi Novikau on 30.06.2016.
 */
public interface IPaper {
    /**
     * Prints information about a paper
     */
    void print();
}
