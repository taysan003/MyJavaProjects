package by.training.javalab.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Created by Artsemi Novikau on 30.06.2016.
 */
@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
public @interface Equal {
    /**
     * Options for compare
     */
    enum CompareBy {
        REFERENCE, VALUE;
    }

    /**
     * Fields for check equality
     * @return comparing option
     */
    CompareBy compareBy();
}
