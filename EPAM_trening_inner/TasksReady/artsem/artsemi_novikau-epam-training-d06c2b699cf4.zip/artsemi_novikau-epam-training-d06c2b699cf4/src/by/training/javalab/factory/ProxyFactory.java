package by.training.javalab.factory;

import by.training.javalab.annotation.Proxy;
import by.training.javalab.iface.IPaper;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;

/**
 * Created by Artsemi Novikau on 30.06.2016.
 */
public final class ProxyFactory {
    private ProxyFactory() { }

    /**
     * Checking for @Proxy annotation and creates a proxy object if it presents,
     * otherwise creates a simple instance of a class
     * @param clazz class for checking and creation
     * @return a proxy object if annotation presents or a simple instance
     * @throws NoSuchMethodException if class doesn't contain general-purpose constructor
     * @throws IllegalAccessException IllegalAccessException
     * @throws InvocationTargetException InvocationTargetException
     * @throws InstantiationException InstantiationException
     */
    public static Object getInstance(final Class<? extends IPaper> clazz) throws NoSuchMethodException,
            IllegalAccessException, InvocationTargetException, InstantiationException {
        IPaper instance = clazz.getConstructor().newInstance();

        if (clazz.isAnnotationPresent(Proxy.class)) {
            Proxy proxy = clazz.getAnnotation(Proxy.class);
            InvocationHandler handler;
            handler = proxy.handler().getDeclaredConstructor(IPaper.class).newInstance(instance);
            instance = (IPaper) java.lang.reflect.Proxy.newProxyInstance(clazz.getClassLoader(),
                    new Class[]{IPaper.class}, handler);
        }
        return instance;
    }
}
