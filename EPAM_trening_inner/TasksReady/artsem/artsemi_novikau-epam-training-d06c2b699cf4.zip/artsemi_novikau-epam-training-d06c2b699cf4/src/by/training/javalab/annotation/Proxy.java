package by.training.javalab.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.InvocationHandler;

/**
 * Created by Artsemi Novikau on 30.06.2016.
 */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
public @interface Proxy {
    /**
     * Suitability for object creation
     * @return suitable object of InvokationHandler type
     */
    Class<? extends InvocationHandler> handler();
}
