package by.training.reflection.partB;

/**
 * The enum Type.
 */
public enum Type {
    /**
     * Reference type.
     */
    REFERENCE,
    /**
     * Value type.
     */
    VALUE
}
