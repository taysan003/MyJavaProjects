package by.training.reflection.partA;

/**
 * Created by Vladislav on 18.06.2016.
 */
public interface IShape {
    /**
     * Calculate area double.
     *
     * @return the double
     */
    double calculateArea();

    /**
     * Sets length.
     *
     * @param length the length
     */
    void setLength(double length);
}
