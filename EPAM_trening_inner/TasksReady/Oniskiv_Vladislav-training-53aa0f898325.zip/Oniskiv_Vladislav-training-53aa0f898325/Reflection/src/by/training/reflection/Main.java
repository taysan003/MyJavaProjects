package by.training.reflection;

import by.training.reflection.partA.*;
import by.training.reflection.partB.AnalyzerClass;
import by.training.reflection.partB.ClassValues;

import java.util.*;

/**
 * The type Main.
 */
public final class Main {

    private Main() {
    }

    /**
     * Main.
     *
     * @param args the args
     */
    public static void main(final String[] args) {
        System.out.println("          Part A");
        List<IShape> shapes = new ArrayList<IShape>();
        shapes.add((IShape) FactoryClass.getInstanceOf(Square.class));
        shapes.add((IShape) FactoryClass.getInstanceOf(Triangle.class));
        for (IShape shape : shapes) {
            shape.setLength(4);
            System.out.println("Area: " + shape.calculateArea());
        }

        System.out.println("\n\n\n          Part B");

        ClassValues obj1 = new ClassValues(new Double(123), "reflection");
        ClassValues obj2 = new ClassValues(123.0, "reflection");
        boolean result = AnalyzerClass.equalObjects(obj1, obj2);
        String s;
        if (result) {
            s = "objects are equal";
        } else {
            s = "objects are not equal";
        }
        System.out.println("The result of the comparison: " + s);
    }
}
