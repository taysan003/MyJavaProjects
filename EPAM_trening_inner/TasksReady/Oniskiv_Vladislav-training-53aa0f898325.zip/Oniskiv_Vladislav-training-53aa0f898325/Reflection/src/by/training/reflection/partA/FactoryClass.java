package by.training.reflection.partA;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;

/**
 * Created by Vladislav on 18.06.2016.
 */
public final class FactoryClass {
    private FactoryClass() {
    }

    /**
     * Gets instance of.
     *
     * @param cObj the c obj
     * @return the instance of
     */
    public static Object getInstanceOf(final Class<?> cObj) {
        boolean isAnnotation = cObj.isAnnotationPresent(Proxy.class);
        if (isAnnotation) {
            System.out.println("Creating a proxy class for " + cObj.getSimpleName());
            Proxy proxyAnnatation = (Proxy) cObj.getAnnotation(Proxy.class);
            try {
                Class<?> proxyClass = Class.forName(proxyAnnatation.invocationHandler());
                Constructor<?> constr = proxyClass.getConstructor(new Class[]{Object.class});
                InvocationHandler invoc = (InvocationHandler) constr.newInstance(new Object[]{cObj.newInstance()});
                return java.lang.reflect.Proxy.newProxyInstance(cObj.getClassLoader(), cObj.getInterfaces(), invoc);
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (NoSuchMethodException e) {
                e.printStackTrace();
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InstantiationException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
        } else {
            System.out.println("Creating a normal class for "  + cObj.getSimpleName());
            try {
                return cObj.newInstance();
            } catch (InstantiationException e) {
                e.printStackTrace();
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
        }
        return null;
    }
}
