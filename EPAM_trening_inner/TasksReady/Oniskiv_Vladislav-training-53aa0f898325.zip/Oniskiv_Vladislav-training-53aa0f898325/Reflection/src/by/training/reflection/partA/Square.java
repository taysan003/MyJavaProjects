package by.training.reflection.partA;

/**
 * Created by Vladislav on 18.06.2016.
 */
@Proxy(invocationHandler = "by.training.reflection.partA.ProxyInvocationHandler")
public class Square implements IShape {
    private double lengthSide;

    @Override
    public double calculateArea() {
        return lengthSide * lengthSide;
    }

    @Override
    public void setLength(final double length) {
        lengthSide = length;
    }
}
