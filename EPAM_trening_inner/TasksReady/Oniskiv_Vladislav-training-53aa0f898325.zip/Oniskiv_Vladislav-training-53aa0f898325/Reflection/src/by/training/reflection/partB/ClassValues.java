package by.training.reflection.partB;

/**
 * Created by Vladislav on 14.06.2016.
 */
public class ClassValues {
    /**
     * The X.
     */
    @Equal(compareby = Type.VALUE)
    private Double x;
    /**
     * The Y.
     */
    @Equal(compareby = Type.REFERENCE)
    private String y;

    /**
     * Instantiates a new Class values.
     *
     * @param x the x
     * @param y the y
     */
    public ClassValues(final Double x, final String y) {
        this.x = x;
        this.y = y;
    }

    /**
     * Gets x.
     *
     * @return the x
     */
    public Double getX() {
        return x;
    }

    /**
     * Gets y.
     *
     * @return the y
     */
    public String getY() {
        return y;
    }
}
