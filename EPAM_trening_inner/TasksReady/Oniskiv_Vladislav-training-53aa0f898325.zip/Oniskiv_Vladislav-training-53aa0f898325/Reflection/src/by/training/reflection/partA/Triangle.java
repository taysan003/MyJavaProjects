package by.training.reflection.partA;

/**
 * Created by Vladislav on 18.06.2016.
 */
public class Triangle implements IShape {
    private double lengthSide;

    @Override
    public double calculateArea() {
        return (Math.pow(3, 1.0 / 3) * Math.pow(lengthSide, 2)) / 4;
    }

    @Override
    public void setLength(final double length) {
        lengthSide = length;
    }
}
