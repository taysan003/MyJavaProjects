package by.training.reflection.partB;

import java.lang.reflect.Field;

/**
 * Created by Vladislav on 14.06.2016.
 */
public final class AnalyzerClass {

    private AnalyzerClass() {
    }

    /**
     * Equal objects boolean.
     *
     * @param object1 the object 1
     * @param object2 the object 2
     * @return the boolean
     */
    public static boolean equalObjects(final Object object1, final Object object2) {
        boolean result = true;
        Class<?> obj1 = object1.getClass();
        Class<?> obj2 = object2.getClass();
        Field[] fields = obj1.getDeclaredFields();
        for (Field field1 : fields) {
            try {
                field1.setAccessible(true);
                Field field2 = obj2.getDeclaredField(field1.getName());
                field2.setAccessible(true);
                Equal equal = field1.getAnnotation(Equal.class);
                Type type = equal.compareby();
                switch (type) {
                    case REFERENCE:
                        if (field1.get(object1) != field2.get(object2)) {
                            result = false;
                        }
                        break;
                    case VALUE:
                       if (!field1.get(object1).equals(field2.get(object2))) {
                            result = false;
                        }
                        break;
                    default:
                        break;
                }
            } catch (NoSuchFieldException e) {
                e.printStackTrace();
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
        }
        return result;
    }
}
