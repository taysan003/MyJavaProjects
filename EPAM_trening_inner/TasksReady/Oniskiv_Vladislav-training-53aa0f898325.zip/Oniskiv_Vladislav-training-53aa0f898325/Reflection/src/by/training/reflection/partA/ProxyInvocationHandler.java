package by.training.reflection.partA;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

/**
 * Created by Vladislav on 18.06.2016.
 */
public class ProxyInvocationHandler implements InvocationHandler {
    private Object shape;

    /**
     * Instantiates a new Proxy invocation handler.
     *
     * @param shape the shape
     */
    public ProxyInvocationHandler(final Object shape) {
        this.shape = shape;
    }

    @Override
    public Object invoke(final Object proxy, final Method method, final Object[] args) throws Throwable {
        System.out.println("Invoke method of class " + shape.getClass().getSimpleName());
        return method.invoke(shape, args);
    }
}
