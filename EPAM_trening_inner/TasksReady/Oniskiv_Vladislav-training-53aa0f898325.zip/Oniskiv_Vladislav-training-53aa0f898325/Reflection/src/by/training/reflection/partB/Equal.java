package by.training.reflection.partB;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Created by Vladislav on 14.06.2016.
 */
@Target(value = ElementType.FIELD)
@Retention(value = RetentionPolicy.RUNTIME)
public @interface Equal {
    /**
     * Compareby state.
     *
     * @return the state
     */
    Type compareby();
}
