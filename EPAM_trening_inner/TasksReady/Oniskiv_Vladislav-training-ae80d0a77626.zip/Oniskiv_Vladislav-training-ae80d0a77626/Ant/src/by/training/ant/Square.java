package by.training.ant;

/**
 * Created by Vladislav on 03.06.2016.
 */
public class Square implements Shape {
    @Override
    public void myName() {
        System.out.println("My name`s square");
    }
}
