package by.training.ant;

/**
 * Created by Vladislav on 03.06.2016.
 */
public interface Shape {
    /**
     * My name.
     */
    void myName();
}
