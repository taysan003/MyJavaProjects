package by.training.jspTag.tags;

import javax.servlet.ServletContext;
import javax.servlet.ServletRegistration;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.BodyTagSupport;
import javax.servlet.jsp.tagext.IterationTag;
import java.util.*;

/**
 * Created by Vladislav on 19.06.2016.
 */
public class ListMapping extends BodyTagSupport {

    private int i = 0;
    private Map<String, String> mappings;
    private Iterator<String> keysI;


    @Override
    public int doStartTag() throws JspException {
        mappings = new HashMap<String, String>();
        ServletContext context = this.pageContext.getServletContext();
        Map<String, ? extends ServletRegistration> registrations = context.getServletRegistrations();
        Set<String> keysS = registrations.keySet();
        keysI = keysS.iterator();
        while (keysI.hasNext()) {
            String key = keysI.next();
            ServletRegistration registr = registrations.get(key);
            Collection<String> urls = registr.getMappings();
            Iterator<String> urlI = urls.iterator();
            while (urlI.hasNext()) {
                String url = urlI.next();
                mappings.put(key, url);
            }
        }
        Set<String> keys = mappings.keySet();
        keysI = keys.iterator();
        return EVAL_BODY_INCLUDE;
    }

    @Override
    public int doAfterBody() throws JspException {
        while (keysI.hasNext()) {
            String key = keysI.next();
            pageContext.setAttribute("url", mappings.get(key));
            pageContext.setAttribute("servlet", key);
            return IterationTag.EVAL_BODY_AGAIN;
        }
        return IterationTag.SKIP_BODY;
    }
}
