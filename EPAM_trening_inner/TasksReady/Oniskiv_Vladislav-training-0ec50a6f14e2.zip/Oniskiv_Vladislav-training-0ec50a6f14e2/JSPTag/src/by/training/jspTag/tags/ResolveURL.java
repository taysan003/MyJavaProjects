package by.training.jspTag.tags;

import javax.servlet.ServletContext;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.JspFragment;
import javax.servlet.jsp.tagext.SimpleTagSupport;
import java.io.IOException;
import java.io.StringWriter;

/**
 * Created by Vladislav on 28.06.2016.
 */
public class ResolveURL extends SimpleTagSupport {
    private String url;

    /**
     * Sets url.
     *
     * @param url the url
     */
    public void setUrl(final String url) {
        this.url = url;
    }

    @Override
    public void doTag() throws JspException, IOException {
        JspWriter out = getJspContext().getOut();
        PageContext pageContext = (PageContext) getJspContext();
        ServletContext servletContext = pageContext.getServletContext();
        String resource = servletContext.getRealPath(url);
        pageContext.setAttribute("url", url);
        pageContext.setAttribute("resource", resource);
        StringWriter sw = new StringWriter();
        JspFragment body = getJspBody();
        body.invoke(sw);
        out.println(sw.toString());
    }
}
