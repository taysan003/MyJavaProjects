package by.training.tdd.containers;

import by.training.tdd.entities.Passenger;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Vladislav on 06.07.2016.
 */
public class ArrivalStory {
    private List<Passenger> passengers;

    public ArrivalStory() {
        this.passengers = new ArrayList<Passenger>();
    }

    public void addPassenger(final Passenger passenger) {
        passengers.add(passenger);
    }

    public boolean isEmpty() {
        return passengers.isEmpty();
    }

    public int countPassengers() {
        return passengers.size();
    }
}
