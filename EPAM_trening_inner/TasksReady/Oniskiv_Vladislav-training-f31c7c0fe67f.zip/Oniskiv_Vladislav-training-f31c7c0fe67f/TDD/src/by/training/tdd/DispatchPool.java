package by.training.tdd;

import by.training.tdd.entities.Passenger;

/**
 * Created by Vladislav on 06.07.2016.
 */
public class DispatchPool {
    public void setPool(final Passenger passenger) {

    }

    public Passenger getPool() {

    }
}
