package by.training.tdd;

import by.training.tdd.containers.ArrivalStory;
import by.training.tdd.containers.DispatchStory;
import by.training.tdd.entities.Passenger;
import by.training.tdd.entities.Story;

import java.util.Random;

/**
 * Created by Vladislav on 05.07.2016.
 */
public class Building {
    static Random random = new Random(System.currentTimeMillis());

    public static Passenger createPassenger(final int storiesNumber, final int id) {
        int originalStory;
        int destinationStory;
        boolean goUp = true;
        do {
            originalStory = random.nextInt(storiesNumber);
            destinationStory = random.nextInt(storiesNumber);
        } while (originalStory == destinationStory);
        if (originalStory > destinationStory)
            goUp = false;
        return new Passenger(id, originalStory, destinationStory, goUp);
    }

    public static Story[] createStories(final int storiesNumber) {
        Story[] stories = new Story[storiesNumber];
        DispatchStory dispatchStory;
        ArrivalStory arrivalStory;
        DispatchPool dispatchPool;
        for (int i = 0; i < storiesNumber; i++) {
            dispatchStory = new DispatchStory();
            arrivalStory = new ArrivalStory();
            dispatchPool = new DispatchPool();
            stories[i] = new Story(i, dispatchStory, arrivalStory, dispatchPool);
        }
        return stories;
    }

    public static Elevator createElevator(final int elevatorCapacity) {
        return new Elevator(elevatorCapacity);
    }
}
