package by.training.tdd;

import by.training.tdd.entities.Passenger;
import by.training.tdd.enums.TransportationState;

/**
 * Created by Vladislav on 05.07.2016.
 */
public class TranportationTask implements Runnable {
    private Passenger passenger;
    private DispatchPool pool;
    private Elevator elevator;

    public TranportationTask(final Passenger passenger, final DispatchPool pool, final Elevator elevator) {
        this.passenger = passenger;
        this.pool = pool;
        this.elevator = elevator;
    }

    @Override
    public void run() {
        passenger.setTransportationState(TransportationState.IN_PROGRESS);
        pool.setPool(passenger);
        //elevator.setElevator();
        passenger.setTransportationState(TransportationState.COMPLETED);
    }
}
