package by.training.tdd.entities;

import by.training.tdd.enums.TransportationState;

/**
 * Created by Vladislav on 03.07.2016.
 */
public class Passenger {
    private int passengerID;
    private int originalStory;
    private int destinationStory;
    private boolean goUp;
    private TransportationState transportationState;

    public Passenger(final int passengerID, final int originalStory, final int destinationStory, final boolean goUp) {
        this.passengerID = passengerID;
        this.originalStory = originalStory;
        this.destinationStory = destinationStory;
        this.goUp = goUp;
        transportationState = TransportationState.NOT_STARTED;
    }

    public int getPassengerID() {
        return passengerID;
    }

    public int getOriginalStory() {
        return originalStory;
    }

    public int getDestinationStory() {
        return destinationStory;
    }

    public TransportationState getTransportationState() {
        return transportationState;
    }

    public boolean isGoUp() {
        return goUp;
    }

    public void setPassengerID(final int passengerID) {
        this.passengerID = passengerID;
    }

    public void setOriginalStory(final int originalStory) {
        this.originalStory = originalStory;
    }

    public void setDestinationStory(final int destinationStory) {
        this.destinationStory = destinationStory;
    }

    public void setTransportationState(final TransportationState transportationState) {
        this.transportationState = transportationState;
    }

    public void setGoUp(final boolean goUp) {
        this.goUp = goUp;
    }
}
