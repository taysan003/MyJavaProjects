package by.training.tdd.enums;

/**
 * Created by Vladislav on 05.07.2016.
 */
public enum TransportationState {
    NOT_STARTED, //эти значением поле инициализируется при создании экземпляра Passenger
    IN_PROGRESS, //когда создается Transportation Task
    COMPLETED, //когда завершается Transportation Task
    ABORTED; //когда прерывается Transportation Task
}
