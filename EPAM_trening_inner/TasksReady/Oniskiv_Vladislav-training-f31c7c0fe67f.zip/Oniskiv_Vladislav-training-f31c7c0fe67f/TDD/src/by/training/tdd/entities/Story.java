package by.training.tdd.entities;

import by.training.tdd.DispatchPool;
import by.training.tdd.containers.ArrivalStory;
import by.training.tdd.containers.DispatchStory;

/**
 * Created by Vladislav on 05.07.2016.
 */
public class Story {
    private int numberStory;
    private DispatchStory dispatchStoryContainer;
    private ArrivalStory arrivalStoryContainer;
    private DispatchPool dispatchPool;

    public Story(final int numberStory, final DispatchStory dispatchStoryContainer,
                 final ArrivalStory arrivalStoryContainer, final DispatchPool dispatchPool) {
        this.numberStory = numberStory;
        this.dispatchStoryContainer = dispatchStoryContainer;
        this.arrivalStoryContainer = arrivalStoryContainer;
        this.dispatchPool = dispatchPool;
    }

    public int getNumberStory() {
        return numberStory;
    }

    public DispatchStory getDispatchStoryContainer() {
        return dispatchStoryContainer;
    }

    public ArrivalStory getArrivalStoryContainer() {
        return arrivalStoryContainer;
    }

    public DispatchPool getDispatchPool() {
        return dispatchPool;
    }

    public void setNumberStory(final int numberStory) {
        this.numberStory = numberStory;
    }

    public void setDispatchStoryContainer(final DispatchStory dispatchStoryContainer) {
        this.dispatchStoryContainer = dispatchStoryContainer;
    }

    public void setArrivalStoryContainer(final ArrivalStory arrivalStoryContainer) {
        this.arrivalStoryContainer = arrivalStoryContainer;
    }

    public void setDispatchPool(final DispatchPool dispatchPool) {
        this.dispatchPool = dispatchPool;
    }
}
