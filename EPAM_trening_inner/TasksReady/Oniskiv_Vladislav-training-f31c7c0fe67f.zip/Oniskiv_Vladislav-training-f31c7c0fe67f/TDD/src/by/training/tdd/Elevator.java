package by.training.tdd;

import by.training.tdd.entities.Passenger;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Vladislav on 05.07.2016.
 */
public class Elevator {
    private int elevatorCapacity;
    private int currentStory;
    private int nextStory;
    private boolean goUp;
    private List<Passenger> passengers;

    public Elevator(final int elevatorCapacity) {
        this.elevatorCapacity = elevatorCapacity;
        currentStory = 0;
        nextStory = 1;
        goUp = true;
        passengers = new ArrayList<Passenger>(elevatorCapacity);
    }

    public int getElevatorCapacity() {
        return elevatorCapacity;
    }

    public int getCurrentStory() {
        return currentStory;
    }

    public int getNextStory() {
        return nextStory;
    }

    public boolean getGoUp() {
        return goUp;
    }

    public void setElevatorCapacity(final int elevatorCapacity) {
        this.elevatorCapacity = elevatorCapacity;
    }

    public void setCurrentStory(final int currentStory) {
        this.currentStory = currentStory;
    }

    public void setNextStory(final int nextStory) {
        this.nextStory = nextStory;
    }

    public void setGoUp(final boolean goUp) {
        this.goUp = goUp;
    }

    public void addPassenger(final Passenger passenger) {
        passengers.add(passenger);
    }

    public void removePassenger(final Passenger passenger) {
        passengers.remove(passenger);
    }

    public boolean isEmpty() {
        return passengers.isEmpty();
    }

    public boolean isFull() {
        if (passengers.size() == elevatorCapacity) {
            return true;
        }
        return false;
    }

    public int countPassengers() {
        return passengers.size();
    }
}
