package by.training.tdd;

import by.training.tdd.controllers.ElevatorController;

import java.util.*;

/**
 * The type Main.
 */
public final class Main {

    private Main() {
    }

    /**
     * Main.
     *
     * @param args the args
     */
    public static void main(final String[] args) {
        ResourceBundle resource = ResourceBundle.getBundle("properties.config");
        int storiesNumber = Integer.parseInt(resource.getString("storiesNumber"));
        int elevatorCapacity = Integer.parseInt(resource.getString("elevatorCapacity"));
        int passengersNumber = Integer.parseInt(resource.getString("passengersNumber"));
        ElevatorController controller = new ElevatorController(storiesNumber, elevatorCapacity, passengersNumber);
        controller.start();
    }
}
