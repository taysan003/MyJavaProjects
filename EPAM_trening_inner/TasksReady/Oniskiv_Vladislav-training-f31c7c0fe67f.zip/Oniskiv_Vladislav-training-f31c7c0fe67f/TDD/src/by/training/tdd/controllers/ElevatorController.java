package by.training.tdd.controllers;

import by.training.tdd.Building;
import by.training.tdd.Elevator;
import by.training.tdd.TranportationTask;
import by.training.tdd.entities.Passenger;
import by.training.tdd.entities.Story;

/**
 * Created by Vladislav on 05.07.2016.
 */
public class ElevatorController {
    private int storiesNumber;
    private int elevatorCapacity;
    private int passengersNumber;
    private Story[] stories;
    private Elevator elevator;
    private Thread[] tranportationTasks;
    private boolean isRun = true;
    private int passengersTransported;

    public ElevatorController(final int storiesNumber, final int elevatorCapacity, final int passengersNumber) {
        this.storiesNumber = storiesNumber;
        this.elevatorCapacity = elevatorCapacity;
        this.passengersNumber = passengersNumber;
        tranportationTasks = new Thread[passengersNumber];
        passengersTransported = 0;
    }

    public void start() {
        initialization();
        run();
    }

    private void initialization() {
        stories = Building.createStories(storiesNumber);
        elevator = Building.createElevator(elevatorCapacity);
        Passenger passenger;
        for (int i = 0; i < passengersNumber; i++) {
            passenger = Building.createPassenger(storiesNumber, i);
            int story = passenger.getOriginalStory();
            stories[story].getDispatchStoryContainer().addPassenger(passenger);
            tranportationTasks[i] = new Thread(new TranportationTask(passenger, stories[story].getDispatchPool(),
                    elevator));
            tranportationTasks[i].start();
        }
    }

    private void run() {
        while (isRun) {
            if (!elevator.isFull() && !stories[elevator.getCurrentStory()].getDispatchStoryContainer().isEmpty()) {
                letsGoToElevator();
            }
            moveToNext();
        }
    }

    private void letsGoToElevator() {

    }

    private void moveToNext() {
        if (passengersTransported == passengersNumber) {
            isRun = false;
        }
        else {
            directionSelection();
            int currentStory = elevator.getCurrentStory();
            if (elevator.getGoUp()) {
               elevator.setCurrentStory(currentStory + 1);
            }
            else {
                elevator.setCurrentStory(currentStory - 1);
            }
            System.out.println("Лифт переехал с " + currentStory + " на " + elevator.getCurrentStory());
        }
    }

    private void directionSelection() {
        if (elevator.getCurrentStory() == (storiesNumber - 1)) {
            elevator.setGoUp(false);
        }
        else if (elevator.getCurrentStory() == 0) {
            elevator.setGoUp(true);
        }
    }
}
