import org.junit.Test;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;

/**
 * Created by Vladislav on 02.07.2016.
 */
public class TestCalculate{

    /**
     * Test plus.
     */
    @Test
    public void testPlus() {
        //Caclulate cal = new Caclulate();
        //assertThat("Норм", cal.plus(3, 5), is(8));
    }
}
