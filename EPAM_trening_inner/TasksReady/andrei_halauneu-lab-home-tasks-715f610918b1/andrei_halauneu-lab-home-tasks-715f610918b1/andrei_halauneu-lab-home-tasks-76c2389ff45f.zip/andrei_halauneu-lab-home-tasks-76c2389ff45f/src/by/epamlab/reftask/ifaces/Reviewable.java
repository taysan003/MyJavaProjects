package by.epamlab.reftask.ifaces;

/**
 * Created by Andrei Halauneu on 15.06.16.
 */
public interface Reviewable {
        /**
         * Criteria
         */
        void overview();
        }
